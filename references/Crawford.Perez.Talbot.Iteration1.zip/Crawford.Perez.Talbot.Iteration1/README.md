# TriviaMaze
TCSS 360 Main project (Autumn 2020)
ITERATION 1
Due to difficulty in scheduling and coordinating (and one of our members being quarantined after a flight for a week without a computer), our 1st iteration ran from Sunday Nov. 15th to Tuesday Nov 17th.
We were able to create User Stories in Pivotal Tracker and Begin logging our hours in Toggl. The SRS has been updated with newer UML designs and can all be found in the "References" folder in the project folder.
Iteration 2 will be cut short and be from Nov. 18th to Nov. 22nd, but afterwards we will be back to a regular Monday to Sunday iteration cycle.
The Java Application was started with no real complete elements. Iteration 2 will likely have more substantial results.
 - Logan Crawford, Marc Perez, Robbie Talbot
 (Crawfl5, perezm68, Robbie00)
 
