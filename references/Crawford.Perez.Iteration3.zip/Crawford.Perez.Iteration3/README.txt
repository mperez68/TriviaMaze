# TriviaMaze
TCSS 360 Main project (Autumn 2020)

ITERATION 1

Due to difficulty in scheduling and coordinating (and one of our members being quarantined after a flight for a week without a computer), our 1st iteration ran from Sunday Nov. 15th to Tuesday Nov 17th.
We were able to create User Stories in Pivotal Tracker and Begin logging our hours in Toggl. The SRS has been updated with newer UML designs and can all be found in the "References" folder in the project folder.
Iteration 2 will be cut short and be from Nov. 18th to Nov. 22nd, but afterwards we will be back to a regular Monday to Sunday iteration cycle.
The Java Application was started with no real complete elements. Iteration 2 will likely have more substantial results.

ITERATION 2

In iteration 2 we began proceeding in accordance to the original design plan. In the development process we began to encounter difficulties adhering to our initial set of requirements and began to rework our
specifications to match a more feasible design schema. Updates to the UML and SRS are in order and the commits made to the repository reflect the new design which will be fairly simpler. The changes and communication
between group members in this iteration has made the goals and outlines for the project much more definitive.

ITERATION 3

Redesigns have been complete and we were able to work on the database. The GUI is loosely operational and we expect the project to be finished next week. Most significantly, with the GUI present we are able to
officially begin checking off user stories.

 - Logan Crawford, Marc Perez, Robbie Talbot
 (Crawfl5, perezm68, Robbie00)
